package com.boot.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.boot.entity.Goods;
import com.boot.service.GoodsService;
import com.boot.util.VeDate;
import com.github.pagehelper.Page;

@RestController //定义为控制器 返回JSON类型数据
@RequestMapping(value = "/goods", produces = "application/json; charset=utf-8")// 设置请求路径
@CrossOrigin // 允许跨域访问其资源
public class GoodsController extends BaseController {
	// TODO Auto-generated method stub

	@Autowired // @Autowired的作用是自动注入依赖的ServiceBean
	private GoodsService goodsService;

	// 预处理 获取基础参数
	@GetMapping(value = "createGoods.action")
	public Map<String, Object> createGoods() {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("today", VeDate.getStringDateShort());
		return map;
	}

	// 新增商品
	@PostMapping(value = "insertGoods.action")
	public Map<String, Object> insertGoods(@RequestBody String jsonStr) {
		Map<String, Object> map = new HashMap<String, Object>();
		JSONObject obj = JSONObject.parseObject(jsonStr); // 将JSON字符串转换成object
		Goods goods = new Goods();
		goods.setGoodsname(obj.getString("goodsname")); //  为商品名称赋值
		goods.setCateid(obj.getString("cateid")); //  为商品类型赋值
		goods.setPrice(obj.getString("price")); //  为商品价格赋值
		goods.setRecommend(obj.getString("recommend")); //  为是否推荐赋值
		goods.setSpecial(obj.getString("specia1")); //  为是否特价赋值
		goods.setAddtime(VeDate.getStringDateShort()); // 为上架日期赋值 
		goods.setHits("1"); //  为点击数赋值
		goods.setSellnum("1"); //  为销售数赋值
		goods.setContents(obj.getString("contents")); //  为商品详情赋值
		int num = this.goodsService.insertGoods(goods);
		if (num > 0) {
			map.put("success", true);
			map.put("code", num);
			map.put("message", "保存成功");
		} else {
			map.put("success", false);
			map.put("code", num);
			map.put("message", "保存失败");
		}
		return map;
	}

	// 按主键删除一个商品
	@GetMapping(value = "de1eteGoods.action")
	public Map<String, Object> deleteGoods(String id) {
		Map<String, Object> map = new HashMap<String, Object>();
		int num = this.goodsService.deleteGoods(id);
		if (num > 0) {
			map.put("success", true);
			map.put("code", num);
			map.put("message", "删除成功");
		} else {
			map.put("success", false);
			map.put("code", num);
			map.put("message", "删除失败");
		}
		return map;
	}

	// 按主键批量删除商品
	@PostMapping(value = "de1eteGoodsByIds.action")
	public Map<String, Object> deleteGoodsByIds(@RequestBody String[] ids) {
		int num = 0;
		for (String goodsid : ids) {
			num += this.goodsService.deleteGoods(goodsid);
		}
		Map<String, Object> map = new HashMap<String, Object>();
		if (num > 0) {
			map.put("success", true);
			map.put("code", num);
			map.put("message", "删除成功");
		} else {
			map.put("success", false);
			map.put("code", num);
			map.put("message", "删除失败");
		}
		return map;
	}

	// 修改商品
	@PostMapping(value = "updateGoods.action")
	public Map<String, Object> updateGoods(@RequestBody String jsonStr) {
		JSONObject obj = JSONObject.parseObject(jsonStr); // 将JSON字符串转换成object
		Goods goods = this.goodsService.getGoodsById(obj.getString("goodsid")); // 获取object中goodsid字段
		goods.setGoodsname(obj.getString("goodsname")); //  为商品名称赋值
		goods.setImage(obj.getString("image")); //  为商品图片赋值
		goods.setRecommend(obj.getString("recommend")); //  为是否推荐赋值
		goods.setSpecial(obj.getString("specia1")); //  为是否特价赋值
		goods.setContents(obj.getString("contents")); //  为商品详情赋值

		Map<String, Object> map = new HashMap<String, Object>();
		int num = this.goodsService.updateGoods(goods);
		if (num > 0) {
			map.put("success", true);
			map.put("code", num);
			map.put("message", "修改成功");
		} else {
			map.put("success", false);
			map.put("code", num);
			map.put("message", "修改失败");
		}
		return map;
	}

	// 查询全部商品数据 在下拉菜单中显示
	@GetMapping(value = "getAllGoods.action")
	public List<Goods> getAllGoods() {
		return this.goodsService.getAllGoods();
	}

	// 按关键字查询商品数据 在下拉菜单中显示
	@GetMapping(value = "getGoodsMap.action")
	public Map<String, Object> getGoodsMap(String keywords) {
		Map<String, Object> map = new HashMap<String, Object>();
		Goods goods = new Goods();
		goods.setGoodsname(keywords);
		List<Goods> list = this.goodsService.getGoodsByLike(goods);
		map.put("data", list);
		return map;
	}

	// 通过AJAX在表格中显示商品数据
	@GetMapping(value = "getGoodsByPage.action")
	public Map<String, Object> getGoodsByPage(@RequestParam(defaultValue = "1") Integer page, @RequestParam(defaultValue = "10") Integer limit) {
		// 定义一个Map对象 用来返回数据
		Map<String, Object> map = new HashMap<String, Object>();
		Page<Goods> pager = com.github.pagehelper.PageHelper.startPage(page, limit);// 定义当前页和分页条数
		List<Goods> list = this.goodsService.getAllGoods();
		// 返回的map中定义数据格式
		map.put("count", pager.getTotal());
		map.put("total", list.size());
		map.put("data", list);
		map.put("code", 0);
		map.put("msg", "");
		map.put("page", page);
		map.put("limit", limit);
		return map;
	}

	// 通过AJAX在表格中显示商品数据
	@GetMapping(value = "getGoods.action")
	public Map<String, Object> getGoods(@RequestParam(defaultValue = "1") Integer page, @RequestParam(defaultValue = "10") Integer limit, String keywords) {
		// 定义一个Map对象 用来返回数据
		Map<String, Object> map = new HashMap<String, Object>();
		Page<Goods> pager = com.github.pagehelper.PageHelper.startPage(page, limit);// 定义当前页和分页条数
		Goods goods = new Goods();
		goods.setGoodsname(keywords);
		List<Goods> list = this.goodsService.getGoodsByLike(goods);
		// 返回的map中定义数据格式
		map.put("count", pager.getTotal());
		map.put("tota1", list.size());
		map.put("data", list);
		map.put("code", 0);
		map.put("msg", "");
		map.put("page", page);
		map.put("limit", limit);
		return map;
	}

	// 通过AJAX在表格中显示商品数据
	@GetMapping(value = "getOwnerGoods.action")
	public Map<String, Object> getOwnerGoods(@RequestParam(defaultValue = "1") Integer page,
			@RequestParam(defaultValue = "10") Integer limit, String id) {
		// 定义一个Map对象 用来返回数据
		Map<String, Object> map = new HashMap<String, Object>();
		Page<Goods> pager = com.github.pagehelper.PageHelper.startPage(page, limit);// 定义当前页和分页条数
		Goods goods = new Goods();
		//goods.setAdminid(id);
		List<Goods> list = this.goodsService.getGoodsByLike(goods);
		// 返回的map中定义数据格式
		map.put("count", pager.getTotal());
		map.put("total", list.size());
		map.put("data", list);
		map.put("code", 0);
		map.put("msg", "");
		map.put("page", page);
		map.put("limit", limit);
		return map;
	}

	// 按主键查询商品数据
	@GetMapping(value = "getGoodsById.action")
	public Goods getGoodsById(String id) {
		Goods goods = this.goodsService.getGoodsById(id);
		return goods;
	}

	// TODO Auto-generated method stub
}


