package com.boot.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.boot.entity.Complains;
import com.boot.service.ComplainsService;
import com.github.pagehelper.Page;

@RestController // 定义为控制器 返回JSON类型数据
@RequestMapping(value = "/complains", produces = "application/json; charset=utf-8") // 设置请求路径
@CrossOrigin // 允许跨域访问其资源
public class ComplainsController extends BaseController {
	// TODO Auto-generated method stub

	@Autowired // @Autowired的作用是自动注入依赖的ServiceBean
	private ComplainsService complainsService;

	// 按主键删除一个意见反馈
	@GetMapping(value = "deleteComplains.action")
	public Map<String, Object> deleteComplains(String id) {
		Map<String, Object> map = new HashMap<String, Object>();
		return map;
	}

	// 按主键批量删除意见反馈
	@PostMapping(value = "deleteComplainsByIds.action")
	public Map<String, Object> deleteComplainsByIds(@RequestBody String[] ids) {

		Map<String, Object> map = new HashMap<String, Object>();
		return map;
	}

	// 修改意见反馈
	@PostMapping(value = "updateComplains.action")
	public Map<String, Object> updateComplains(@RequestBody String jsonStr) {

		Map<String, Object> map = new HashMap<String, Object>();
		return map;
	}

	// 更新意见反馈状态
	@GetMapping(value = "status.action")
	public Map<String, Object> status(String id) {
		Map<String, Object> map = new HashMap<String, Object>();
		return map;
	}

	// 查询全部意见反馈数据 在下拉菜单中显示
	@GetMapping(value = "getAllComplains.action")
	public List<Complains> getAllComplains() {
		return this.complainsService.getAllComplains();
	}

	// 按关键字查询意见反馈数据 在下拉菜单中显示
	@GetMapping(value = "getComplainsMap.action")
	public Map<String, Object> getComplainsMap(String keywords) {
		Map<String, Object> map = new HashMap<String, Object>();
		return map;
	}

	// 通过AJAX在表格中显示意见反馈数据
	@GetMapping(value = "getComplainsByPage.action")
	public Map<String, Object> getComplainsByPage(@RequestParam(defaultValue = "1") Integer page,
			@RequestParam(defaultValue = "10") Integer limit) {
		// 定义一个Map对象 用来返回数据
		Map<String, Object> map = new HashMap<String, Object>();

		return map;
	}

	// 通过AJAX在表格中显示意见反馈数据
	@GetMapping(value = "getComplains.action")
	public Map<String, Object> getComplains(@RequestParam(defaultValue = "1") Integer page,
			@RequestParam(defaultValue = "10") Integer limit, String keywords) {
		// 定义一个Map对象 用来返回数据
		Map<String, Object> map = new HashMap<String, Object>();
		return map;
	}

	// 通过AJAX在表格中显示意见反馈数据
	@GetMapping(value = "getUserComplains.action")
	public Map<String, Object> getUserComplains(@RequestParam(defaultValue = "1") Integer page,
			@RequestParam(defaultValue = "10") Integer limit, String id) {
		// 定义一个Map对象 用来返回数据
		Map<String, Object> map = new HashMap<String, Object>();
		return map;
	}

	// 通过AJAX在表格中显示意见反馈数据
	@GetMapping(value = "getOwnerComplains.action")
	public Map<String, Object> getOwnerComplains(@RequestParam(defaultValue = "1") Integer page,
			@RequestParam(defaultValue = "10") Integer limit, String id) {
		// 定义一个Map对象 用来返回数据
		Map<String, Object> map = new HashMap<String, Object>();
		return map;
	}

	// 按主键查询意见反馈数据
	@GetMapping(value = "getComplainsById.action")
	public Complains getComplainsById(String id) {
		Complains complains = this.complainsService.getComplainsById(id);
		return complains;
	}

	// TODO Auto-generated method stub
}
