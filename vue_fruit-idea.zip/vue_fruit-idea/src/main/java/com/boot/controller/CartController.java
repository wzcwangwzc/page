package com.boot.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.boot.entity.Cart;
import com.boot.service.CartService;
import com.boot.util.VeDate;
import com.github.pagehelper.Page;

@RestController //定义为控制器 返回JSON类型数据//作者QQ 1305637939 定制代码，修改代码可以找我
@RequestMapping(value = "/cart", produces = "application/json; charset=utf-8")// 设置请求路径
@CrossOrigin // 允许跨域访问其资源
public class CartController extends BaseController {
	// TODO Auto-generated method stub

	@Autowired // @Autowired的作用是自动注入依赖的ServiceBean
	private CartService cartService;

	// 预处理 获取基础参数
	@GetMapping(value = "createCart.action")
	public Map<String, Object> createCart() {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("today", VeDate.getStringDateShort());
		return map;
	}

	// 新增购物车
	@PostMapping(value = "insertCart.action")
	public Map<String, Object> insertCart(@RequestBody String jsonStr) {
		Map<String, Object> map = new HashMap<String, Object>();
		JSONObject obj = JSONObject.parseObject(jsonStr); // 将JSON字符串转换成object
		Cart cart = new Cart();
		cart.setUsersid(obj.getString("usersid")); //  为用户赋值
		cart.setGoodsid(obj.getString("goodsid")); //  为商品赋值
		cart.setPrice(obj.getString("price")); //  为单价赋值
		cart.setNum(obj.getString("num")); //  为数量赋值
		cart.setAddtime(VeDate.getStringDateShort()); // 为加入日期赋值 
		int num = this.cartService.insertCart(cart);
		if (num > 0) {
			map.put("success", true);
			map.put("code", num);
			map.put("message", "保存成功");
		} else {
			map.put("success", false);
			map.put("code", num);
			map.put("message", "保存失败");
		}
		return map;
	}

	// 按主键删除一个购物车//作者QQ 1305637939 定制代码，修改代码可以找我
	@GetMapping(value = "deleteCart.action")
	public Map<String, Object> deleteCart(String id) {
		Map<String, Object> map = new HashMap<String, Object>();
		int num = this.cartService.deleteCart(id);
		if (num > 0) {
			map.put("success", true);
			map.put("code", num);
			map.put("message", "删除成功");
		} else {
			map.put("success", false);
			map.put("code", num);
			map.put("message", "删除失败");
		}
		return map;
	}

	// 按主键批量删除购物车
	@PostMapping(value = "deleteCartByIds.action")
	public Map<String, Object> deleteCartByIds(@RequestBody String[] ids) {
		int num = 0;
		for (String cartid : ids) {
			num += this.cartService.deleteCart(cartid);
		}
		Map<String, Object> map = new HashMap<String, Object>();
		if (num > 0) {
			map.put("success", true);
			map.put("code", num);
			map.put("message", "删除成功");
		} else {
			map.put("success", false);
			map.put("code", num);
			map.put("message", "删除失败");
		}
		return map;
	}

	// 修改购物车//作者QQ 1305637939 定制代码，修改代码可以找我
	@PostMapping(value = "updateCart.action")
	public Map<String, Object> updateCart(@RequestBody String jsonStr) {
		JSONObject obj = JSONObject.parseObject(jsonStr); // 将JSON字符串转换成object
		Cart cart = this.cartService.getCartById(obj.getString("cartid")); // 获取object中cartid字段
		cart.setUsersid(obj.getString("usersid")); //  为用户赋值
		cart.setGoodsid(obj.getString("goodsid")); //  为商品赋值
		cart.setPrice(obj.getString("price")); //  为单价赋值
		cart.setNum(obj.getString("num")); //  为数量赋值

		Map<String, Object> map = new HashMap<String, Object>();
		int num = this.cartService.updateCart(cart);
		if (num > 0) {
			map.put("success", true);
			map.put("code", num);
			map.put("message", "修改成功");
		} else {
			map.put("success", false);
			map.put("code", num);
			map.put("message", "修改失败");
		}
		return map;
	}

	// 查询全部购物车数据 在下拉菜单中显示
	@GetMapping(value = "getAllCart.action")
	public List<Cart> getAllCart() {
		return this.cartService.getAllCart();
	}

	// 按关键字查询购物车数据 在下拉菜单中显示
	@GetMapping(value = "getCartMap.action")
	public Map<String, Object> getCartMap(String keywords) {
		Map<String, Object> map = new HashMap<String, Object>();
		Cart cart = new Cart();
		cart.setUsersid(keywords);
		List<Cart> list = this.cartService.getCartByLike(cart);
		map.put("data", list);
		return map;
	}

	// 通过AJAX在表格中显示购物车数据
	@GetMapping(value = "getCartByPage.action")
	public Map<String, Object> getCartByPage(@RequestParam(defaultValue = "1") Integer page, @RequestParam(defaultValue = "10") Integer limit) {
		// 定义一个Map对象 用来返回数据
		Map<String, Object> map = new HashMap<String, Object>();
		Page<Cart> pager = com.github.pagehelper.PageHelper.startPage(page, limit);// 定义当前页和分页条数
		List<Cart> list = this.cartService.getAllCart();
		// 返回的map中定义数据格式
		map.put("count", pager.getTotal());
		map.put("total", list.size());
		map.put("data", list);
		map.put("code", 0);
		map.put("msg", "");
		map.put("page", page);
		map.put("limit", limit);
		return map;
	}

	// 通过AJAX在表格中显示购物车数据
	@GetMapping(value = "getCart.action")
	public Map<String, Object> getCart(@RequestParam(defaultValue = "1") Integer page, @RequestParam(defaultValue = "10") Integer limit, String keywords) {
		// 定义一个Map对象 用来返回数据
		Map<String, Object> map = new HashMap<String, Object>();
		Page<Cart> pager = com.github.pagehelper.PageHelper.startPage(page, limit);// 定义当前页和分页条数
		Cart cart = new Cart();
		cart.setUsersid(keywords);
		List<Cart> list = this.cartService.getCartByLike(cart);
		// 返回的map中定义数据格式
		map.put("count", pager.getTotal());
		map.put("total", list.size());
		map.put("data", list);
		map.put("code", 0);
		map.put("msg", "");
		map.put("page", page);
		map.put("limit", limit);
		return map;
	}

	// 通过AJAX在表格中显示购物车数据//作者QQ 1305637939 定制代码，修改代码可以找我
	@GetMapping(value = "getUserCart.action")
	public Map<String, Object> getUserCart(@RequestParam(defaultValue = "1") Integer page,
			@RequestParam(defaultValue = "10") Integer limit, String id) {
		// 定义一个Map对象 用来返回数据
		Map<String, Object> map = new HashMap<String, Object>();
		Page<Cart> pager = com.github.pagehelper.PageHelper.startPage(page, limit);// 定义当前页和分页条数
		Cart cart = new Cart();
		cart.setUsersid(id);
		List<Cart> list = this.cartService.getCartByLike(cart);
		// 返回的map中定义数据格式
		map.put("count", pager.getTotal());
		map.put("total", list.size());
		map.put("data", list);
		map.put("code", 0);
		map.put("msg", "");
		map.put("page", page);
		map.put("limit", limit);
		return map;
	}

	// 通过AJAX在表格中显示购物车数据
	@GetMapping(value = "getOwnerCart.action")
	public Map<String, Object> getOwnerCart(@RequestParam(defaultValue = "1") Integer page,
			@RequestParam(defaultValue = "10") Integer limit, String id) {
		// 定义一个Map对象 用来返回数据
		Map<String, Object> map = new HashMap<String, Object>();
		Page<Cart> pager = com.github.pagehelper.PageHelper.startPage(page, limit);// 定义当前页和分页条数
		Cart cart = new Cart();
		//cart.setAdminid(id);
		List<Cart> list = this.cartService.getCartByLike(cart);
		// 返回的map中定义数据格式
		map.put("count", pager.getTotal());
		map.put("total", list.size());
		map.put("data", list);
		map.put("code", 0);
		map.put("msg", "");
		map.put("page", page);
		map.put("limit", limit);
		return map;
	}

	// 按主键查询购物车数据
	@GetMapping(value = "getCartById.action")
	public Cart getCartById(String id) {
		Cart cart = this.cartService.getCartById(id);
		return cart;
	}

	// TODO Auto-generated method stub
}

//作者QQ 1305637939 定制代码，修改代码可以找我


