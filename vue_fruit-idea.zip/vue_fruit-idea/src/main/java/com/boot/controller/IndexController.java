package com.boot.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.boot.entity.Article;
import com.boot.entity.Cart;
import com.boot.entity.Cate;
import com.boot.entity.Complains;
import com.boot.entity.Details;
import com.boot.entity.Fav;
import com.boot.entity.Goods;
import com.boot.entity.Items;
import com.boot.entity.Orders;
import com.boot.entity.Topic;
import com.boot.entity.Users;
import com.boot.service.ArticleService;
import com.boot.service.CartService;
import com.boot.service.CateService;
import com.boot.service.ComplainsService;
import com.boot.service.DetailsService;
import com.boot.service.FavService;
import com.boot.service.GoodsService;
import com.boot.service.OrdersService;
import com.boot.service.TopicService;
import com.boot.service.UsersService;
import com.boot.util.VeDate;
import com.github.pagehelper.Page;

@RestController // 定义为控制器 返回JSON类型数据
@RequestMapping(value = "/index", produces = "application/json; charset=utf-8") // 设置请求路径
@CrossOrigin // 允许跨域访问其资源
public class IndexController extends BaseController {

	// @Autowired的作用是自动注入依赖的ServiceBean
	@Autowired
	private UsersService usersService;
	@Autowired
	private ArticleService articleService;
	@Autowired
	private CateService cateService;
	@Autowired
	private GoodsService goodsService;
	@Autowired
	private CartService cartService;
	@Autowired
	private OrdersService ordersService;
	@Autowired
	private DetailsService detailsService;
	@Autowired
	private TopicService topicService;
	@Autowired
	private FavService favService;
	@Autowired
	private ComplainsService complainsService;

	// TODO Auto-generated method stub

	// 预处理 获取基础参数
	@GetMapping(value = "front.action")
	public Map<String, Object> front() {
		Map<String, Object> map = new HashMap<String, Object>();
		List<Cate> cateList = this.cateService.getAllCate();
		map.put("cateList", cateList);
		List<Goods> hotList = this.goodsService.getGoodsByHot();
		map.put("hotList", hotList);
		return map;
	}

	// 前台首页
	@GetMapping(value = "index.action")
	public Map<String, Object> index() {
		Map<String, Object> map = new HashMap<String, Object>();
		List<Cate> cateList = this.cateService.getCateFront();
		List<Cate> frontList = new ArrayList<Cate>();
		for (Cate cate : cateList) {
			List<Goods> goodsList = this.goodsService.getGoodsByCate(cate.getCateid());
			cate.setGoodsList(goodsList);
			frontList.add(cate);
		}
		map.put("frontList", frontList);
		return map;
	}

	// 新闻公告
	@GetMapping(value = "article.action")
	public Map<String, Object> article(@RequestParam(defaultValue = "1") Integer page, @RequestParam(defaultValue = "20") Integer limit) {
		Map<String, Object> map = new HashMap<String, Object>();
		Page<Article> pager = com.github.pagehelper.PageHelper.startPage(page, limit);// 定义当前页和分页条数
		List<Article> list = this.articleService.getAllArticle();
		// 返回的map中定义数据格式
		map.put("count", pager.getTotal());
		map.put("total", list.size());
		map.put("data", list);
		map.put("code", 0);
		map.put("msg", "");
		map.put("page", page);
		map.put("limit", limit);
		return map;
	}

	// 公告详情
	@GetMapping(value = "read.action")
	public Map<String, Object> read(String id) {
		Map<String, Object> map = new HashMap<String, Object>();
		Article article = this.articleService.getArticleById(id);
		article.setHits("" + (Integer.parseInt(article.getHits()) + 1));
		this.articleService.updateArticle(article);
		map.put("article", article);
		return map;
	}

	// 用户登录
	@PostMapping(value = "login.action")
	public Map<String, Object> login(@RequestBody String jsonStr) {
		Map<String, Object> map = new HashMap<String, Object>();
		JSONObject obj = JSONObject.parseObject(jsonStr);
		String username = obj.getString("username");
		String password = obj.getString("password");
		Users usersEntity = new Users();
		usersEntity.setUsername(username);
		List<Users> userslist = this.usersService.getUsersByCond(usersEntity);
		if (userslist.size() == 0) {
			map.put("success", false);
			map.put("message", "用户名不存在");
		} else {
			Users users = userslist.get(0);
			if (password.equals(users.getPassword())) {
				map.put("success", true);
				map.put("message", "登录成功");
				map.put("userid", users.getUsersid());
				map.put("username", users.getUsername());
				map.put("realname", users.getRealname());
			} else {
				map.put("success", false);
				map.put("message", "密码错误");
			}
		}
		return map;
	}

	// 用户注册
	@PostMapping(value = "register.action")
	public Map<String, Object> register(@RequestBody String jsonStr) {
		Map<String, Object> map = new HashMap<String, Object>();
		JSONObject obj = JSONObject.parseObject(jsonStr); // 将JSON字符串转换成object
		Users users = new Users();
		users.setUsername(obj.getString("username"));
		users.setPassword(obj.getString("password"));
		users.setSex(obj.getString("sex"));
		users.setBirthday(obj.getString("birthday"));
		int num = this.usersService.insertUsers(users);
		if (num > 0) {
			map.put("success", true);
			map.put("code", num);
			map.put("message", "注册成功");
		} else {
			map.put("success", false);
			map.put("code", num);
			map.put("message", "注册失败");
		}
		return map;
	}

	// 修改密码
	@PostMapping(value = "editpwd.action")
	public Map<String, Object> editpwd(@RequestBody String jsonStr) {
		Map<String, Object> map = new HashMap<String, Object>();
		JSONObject obj = JSONObject.parseObject(jsonStr); // 将JSON字符串转换成object
		String userid = obj.getString("userid");
		String password = obj.getString("password");
		String repassword = obj.getString("repassword");
		int num = 0;
		Users users = this.usersService.getUsersById(userid);
		if (password.equals(users.getPassword())) {
			users.setPassword(repassword);
			num = 1;
			if (num > 0) {
				map.put("success", true);
				map.put("code", num);
				map.put("message", "修改成功");
			} else {
				map.put("success", false);
				map.put("code", num);
				map.put("message", "修改失败");
			}
		} else {
			map.put("success", false);
			map.put("code", num);
			map.put("message", "旧密码错误");
		}
		return map;
	}

	// 查看个人信息
	@GetMapping(value = "userinfo.action")
	public Map<String, Object> userinfo(String id) {
		Map<String, Object> map = new HashMap<String, Object>();
		Users users = this.usersService.getUsersById(id);
		map.put("users", users);
		return map;
	}

	// 修改个人信息
	@PostMapping(value = "personal.action")
	public Map<String, Object> personal(@RequestBody String jsonStr) {
		Map<String, Object> map = new HashMap<String, Object>();
		JSONObject obj = JSONObject.parseObject(jsonStr); // 将JSON字符串转换成object
		Users users = this.usersService.getUsersById(obj.getString("usersid"));
		int num = 1;
		if (num > 0) {
			map.put("success", true);
			map.put("code", num);
			map.put("message", "修改成功");
		} else {
			map.put("success", false);
			map.put("code", num);
			map.put("message", "修改失败");
		}
		return map;
	}

	// 查看购物车
	@GetMapping(value = "cart.action")
	public Map<String, Object> cart(String userid) {
		Map<String, Object> map = new HashMap<String, Object>();
		Cart cart = new Cart();
		cart.setUsersid(userid);
		List<Cart> cartList = this.cartService.getCartByCond(cart);
		map.put("cartList", cartList);
		map.put("num", cartList.size());
		return map;
	}

	// 删除购物车中的商品
	@RequestMapping(value = "deletecart.action")
	public Map<String, Object> deletecart(String id) {
		Map<String, Object> map = new HashMap<String, Object>();
		int num = this.cartService.deleteCart(id);
		if (num > 0) {
			map.put("success", true);
			map.put("code", num);
			map.put("message", "删除成功");
		} else {
			map.put("success", false);
			map.put("code", num);
			map.put("message", "删除失败");
		}
		return map;
	}

	// 查看订单
	@RequestMapping(value = "showOrders.action")
	public Map<String, Object> showOrders(@RequestParam(defaultValue = "1") Integer page, @RequestParam(defaultValue = "10") Integer limit,
			String userid) {
		Map<String, Object> map = new HashMap<String, Object>();
		Orders orders = new Orders();
		orders.setUsersid(userid);
		Page<Orders> pager = com.github.pagehelper.PageHelper.startPage(page, limit);// 定义当前页和分页条数
		List<Orders> list = this.ordersService.getOrdersByCond(orders);
		return map;
	}

	// 查看订单明细
	@RequestMapping(value = "orderdetail.action")
	public Map<String, Object> orderdetail(String id) {

		return null;
	}

	// 添加商品到购物车
	@PostMapping(value = "addcart.action")
	public Map<String, Object> addcart(@RequestBody String jsonStr) {
		Map<String, Object> map = new HashMap<String, Object>();
		JSONObject obj = JSONObject.parseObject(jsonStr); // 将JSON字符串转换成object
		Cart cart = new Cart();
		cart.setUsersid(obj.getString("userid"));
		cart.setAddtime(VeDate.getStringDateShort());
		cart.setGoodsid(obj.getString("goodsid"));
		cart.setNum(obj.getString("num"));
		cart.setPrice(obj.getString("price"));
		int num = this.cartService.insertCart(cart);
		if (num > 0) {
			map.put("success", true);
			map.put("code", num);
			map.put("message", "成功");
		} else {
			map.put("success", false);
			map.put("code", num);
			map.put("message", "失败");
		}
		return map;
	}

	// 购物结算
	@RequestMapping(value = "checkout.action", method = RequestMethod.POST)
	public Map<String, Object> checkout(@RequestBody String jsonStr) {
		return null;
	}

	// 确认收货
	@RequestMapping(value = "over.action")
	public Map<String, Object> over(String id) {
		return null;
	}

	@RequestMapping(value = "prePay.action")
	public Map<String, Object> prePay(String id) {
		Map<String, Object> map = new HashMap<String, Object>();
		Orders orders = this.ordersService.getOrdersById(id);
		map.put("orders", orders);
		return map;
	}

	// 付款
	@RequestMapping(value = "pay.action")
	public Map<String, Object> pay(String id) {
		return null;
	}

	// 取消订单
	@RequestMapping(value = "cancel.action")
	public Map<String, Object> cancel(String id) {
		return null;
	}

	// 加入收藏
	@PostMapping(value = "addFav.action")
	public Map<String, Object> addFav(@RequestBody String jsonStr) {
		Map<String, Object> map = new HashMap<String, Object>();
		JSONObject obj = JSONObject.parseObject(jsonStr); // 将JSON字符串转换成object
		int num = 0;
		Fav fav = new Fav();
		fav.setUsersid(obj.getString("userid"));
		fav.setGoodsid(obj.getString("goodsid"));
		List<Fav> list = this.favService.getFavByCond(fav);
		if (list.size() != 0) {
			map.put("success", false);
			map.put("code", num);
			map.put("message", "您已经收藏本商品");
			return map;
		}
		fav.setAddtime(VeDate.getStringDateShort());
		num = this.favService.insertFav(fav);
		if (num > 0) {
			map.put("success", true);
			map.put("code", num);
			map.put("message", "收藏成功");
		} else {
			map.put("success", false);
			map.put("code", num);
			map.put("message", "收藏失败");
		}
		return map;
	}

	// 我的收藏
	@GetMapping(value = "myFav.action")
	public Map<String, Object> myFav(String userid, @RequestParam(defaultValue = "1") Integer page,
			@RequestParam(defaultValue = "10") Integer limit) {
		Map<String, Object> map = new HashMap<String, Object>();
		Page<Fav> pager = com.github.pagehelper.PageHelper.startPage(page, limit);// 定义当前页和分页条数
		Fav fav = new Fav();
		fav.setUsersid(userid);
		List<Fav> list = this.favService.getFavByCond(fav);
		// 返回的map中定义数据格式
		map.put("count", pager.getTotal());
		map.put("total", list.size());
		map.put("data", list);
		map.put("code", 0);
		map.put("msg", "");
		map.put("page", page);
		map.put("limit", limit);
		return map;
	}

	// 删除收藏
	@RequestMapping(value = "deleteFav.action")
	public Map<String, Object> deleteFav(String id) {
		return null;
	}

	// 添加意见反馈信息
	@PostMapping(value = "addComplains.action")
	public Map<String, Object> addComplains(@RequestBody String jsonStr) {
		Map<String, Object> map = new HashMap<String, Object>();
		JSONObject obj = JSONObject.parseObject(jsonStr); // 将JSON字符串转换成object
		Complains complains = new Complains();
		complains.setAddtime(VeDate.getStringDateShort());
		complains.setStatus("");
		complains.setReps(" ");
		int num = this.complainsService.insertComplains(complains);
		if (num > 0) {
			map.put("success", true);
			map.put("code", num);
			map.put("message", "反馈成功");
		} else {
			map.put("success", false);
			map.put("code", num);
			map.put("message", "反馈失败");
		}
		return map;
	}

	// 我的意见反馈信息
	@RequestMapping(value = "myComplains.action")
	public Map<String, Object> myComplains(@RequestParam(defaultValue = "1") Integer page, @RequestParam(defaultValue = "12") Integer limit,
			String userid) {
		Map<String, Object> map = new HashMap<String, Object>();
		Complains complains = new Complains();
		complains.setUsersid(userid);
		// 定义当前页和分页条数
		Page<Complains> pager = com.github.pagehelper.PageHelper.startPage(page, limit);
		List<Complains> complainsList = this.complainsService.getComplainsByCond(complains);
		return map;
	}

	@RequestMapping(value = "cate.action")
	public Map<String, Object> cate(@RequestParam(defaultValue = "1") Integer page, @RequestParam(defaultValue = "12") Integer limit,
			String id) {
		System.out.println("cateid  ==>  " + id);
		Map<String, Object> map = new HashMap<String, Object>();
		Cate cate = this.cateService.getCateById(id);
		Goods goods = new Goods();
		goods.setCateid(id);
		Page<Goods> pager = com.github.pagehelper.PageHelper.startPage(page, limit);// 定义当前页和分页条数
		List<Goods> goodsList = this.goodsService.getGoodsByCond(goods);
		// 返回的map中定义数据格式
		map.put("count", pager.getTotal());
		map.put("total", goodsList.size());
		map.put("code", 0);
		map.put("msg", "");
		map.put("page", page);
		map.put("limit", limit);
		map.put("cate", cate);
		return map;
	}

	@RequestMapping(value = "recommend.action")
	public Map<String, Object> recommend(@RequestParam(defaultValue = "1") Integer page, @RequestParam(defaultValue = "12") Integer limit) {
		Map<String, Object> map = new HashMap<String, Object>();
		Goods goods = new Goods();
		Page<Goods> pager = com.github.pagehelper.PageHelper.startPage(page, limit);// 定义当前页和分页条数
		List<Goods> goodsList = this.goodsService.getGoodsByCond(goods);
		// 返回的map中定义数据格式
		map.put("data", goodsList);
		map.put("code", 0);
		return map;
	}

	@RequestMapping(value = "special.action")
	public Map<String, Object> special(@RequestParam(defaultValue = "1") Integer page, @RequestParam(defaultValue = "12") Integer limit) {
		Map<String, Object> map = new HashMap<String, Object>();
		Goods goods = new Goods();
		Page<Goods> pager = com.github.pagehelper.PageHelper.startPage(page, limit);// 定义当前页和分页条数
		List<Goods> goodsList = this.goodsService.getGoodsByCond(goods);
		// 返回的map中定义数据格式
		map.put("count", pager.getTotal());
		map.put("total", goodsList.size());
		map.put("data", goodsList);
		map.put("code", 0);
		return map;
	}

	@RequestMapping(value = "all.action")
	public Map<String, Object> all(@RequestParam(defaultValue = "1") Integer page, @RequestParam(defaultValue = "12") Integer limit) {
		Map<String, Object> map = new HashMap<String, Object>();
		Page<Goods> pager = com.github.pagehelper.PageHelper.startPage(page, limit);// 定义当前页和分页条数
		List<Goods> goodsList = this.goodsService.getAllGoods();
		// 返回的map中定义数据格式
		map.put("count", pager.getTotal());
		map.put("total", goodsList.size());
		map.put("data", goodsList);
		map.put("code", 0);
		map.put("msg", "");
		map.put("page", page);
		map.put("limit", limit);
		return map;
	}

	@GetMapping(value = "queryGoods.action")
	public Map<String, Object> queryGoods(@RequestParam(defaultValue = "1") Integer page, @RequestParam(defaultValue = "12") Integer limit,
			String name) {
		System.out.println("name ==>" + name);
		Map<String, Object> map = new HashMap<String, Object>();
		Goods goods = new Goods();
		goods.setGoodsname(name);
		Page<Goods> pager = com.github.pagehelper.PageHelper.startPage(page, limit);// 定义当前页和分页条数
		List<Goods> goodsList = this.goodsService.getGoodsByLike(goods);
		// 返回的map中定义数据格式
		map.put("count", pager.getTotal());
		map.put("total", goodsList.size());
		map.put("data", goodsList);
		map.put("code", 0);
		map.put("msg", "");
		map.put("page", page);
		map.put("limit", limit);
		return map;
	}

	@RequestMapping(value = "detail.action")
	public Map<String, Object> detail(String id) {
		Map<String, Object> map = new HashMap<String, Object>();
		Goods goods = this.goodsService.getGoodsById(id);
		goods.setHits("" + (Integer.parseInt(goods.getHits()) + 1));
		this.goodsService.updateGoods(goods);
		map.put("goods", goods);
		Topic topic = new Topic();
		topic.setGoodsid(id);
		List<Topic> topicList = this.topicService.getTopicByCond(topic);
		map.put("topicList", topicList);
		return map;
	}

	@RequestMapping(value = "preTopic.action")
	public Map<String, Object> preTopic(String id) {
		Map<String, Object> map = new HashMap<String, Object>();
		Orders orders = this.ordersService.getOrdersById(id);
		map.put("orders", orders);
		String ordercode = orders.getOrdercode();
		Details details = new Details();
		details.setOrdercode(ordercode);
		List<Details> detailsList = this.detailsService.getDetailsByCond(details);
		List<Items> itemsList = new ArrayList<Items>();
		for (Details x : detailsList) {
			Items items = new Items();
			items.setDetailsid(x.getDetailsid());
			items.setGoodsid(x.getGoodsid());
			items.setGoodsname(x.getGoodsname());
			items.setOrdercode(ordercode);
			itemsList.add(items);
		}
		map.put("detailsList", itemsList);
		return map;
	}

	@PostMapping(value = "addTopic.action")
	public Map<String, Object> addTopic(@RequestBody String jsonStr) {
		Map<String, Object> map = new HashMap<String, Object>();
		JSONObject obj = JSONObject.parseObject(jsonStr); // 将JSON字符串转换成object
		Orders orders = this.ordersService.getOrdersById(obj.getString("ordersid"));
		this.ordersService.updateOrders(orders);
		JSONArray detailsList = JSONArray.parseArray(obj.getString("detailsList"));
		int num = 0;
		if (num > 0) {
			map.put("success", true);
			map.put("code", num);
			map.put("message", "保存成功");
		} else {
			map.put("success", false);
			map.put("code", num);
			map.put("message", "保存失败");
		}
		return map;
	}

	@SuppressWarnings("rawtypes")
	@RequestMapping(value = "/*", method = RequestMethod.OPTIONS)
	public ResponseEntity handleOptions() {
		return (ResponseEntity) ResponseEntity.noContent();
	}

	// TODO Auto-generated method stub
}
