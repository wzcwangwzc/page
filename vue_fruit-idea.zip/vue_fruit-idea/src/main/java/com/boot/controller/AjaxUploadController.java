package com.boot.controller;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.boot.util.VeDate;

@Controller //定义为控制器//作者QQ 1305637939 定制代码，修改代码可以找我
@RequestMapping(value = "/ajaxupload", produces = "application/json; charset=utf-8")// 设置路径
@CrossOrigin // 允许从不同的域访问其资源
public class AjaxUploadController extends BaseController {

	@PostMapping("upload.action")
	@ResponseBody
	public Map<String, Object> upload(@RequestParam(value = "image", required = false) MultipartFile file) {
		return null;
	}
}

//作者QQ 1305637939 定制代码，修改代码可以找我
































