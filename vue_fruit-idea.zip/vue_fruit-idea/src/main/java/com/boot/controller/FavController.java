package com.boot.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.boot.entity.Fav;
import com.boot.service.FavService;
import com.boot.util.VeDate;
import com.github.pagehelper.Page;

@RestController //定义为控制器 返回JSON类型数据
@RequestMapping(value = "/fav", produces = "application/json; charset=utf-8")// 设置请求路径
@CrossOrigin // 允许跨域访问其资源
public class FavController extends BaseController {
	// TODO Auto-generated method stub

	@Autowired // @Autowired的作用是自动注入依赖的ServiceBean
	private FavService favService;

	// 预处理 获取基础参数
	@GetMapping(value = "createFav.action")
	public Map<String, Object> createFav() {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("today", VeDate.getStringDateShort());
		return map;
	}

	// 新增用户收藏
	@PostMapping(value = "insertFav.action")
	public Map<String, Object> insertFav(@RequestBody String jsonStr) {
		Map<String, Object> map = new HashMap<String, Object>();
		JSONObject obj = JSONObject.parseObject(jsonStr); // 将JSON字符串转换成object
		Fav fav = new Fav();
		fav.setUsersid(obj.getString("usersid")); //  为用户赋值
		fav.setGoodsid(obj.getString("goodsid")); //  为商品赋值
		fav.setAddtime(VeDate.getStringDateShort()); // 为收藏日期赋值 
		int num = this.favService.insertFav(fav);
		if (num > 0) {
			map.put("success", true);
			map.put("code", num);
			map.put("message", "保存成功");
		} else {
			map.put("success", false);
			map.put("code", num);
			map.put("message", "保存失败");
		}
		return map;
	}

	// 按主键删除一个用户收藏
	@GetMapping(value = "deleteFav.action")
	public Map<String, Object> deleteFav(String id) {
		Map<String, Object> map = new HashMap<String, Object>();
		int num = this.favService.deleteFav(id);
		if (num > 0) {
			map.put("success", true);
			map.put("code", num);
			map.put("message", "删除成功");
		} else {
			map.put("success", false);
			map.put("code", num);
			map.put("message", "删除失败");
		}
		return map;
	}

	// 按主键批量删除用户收藏
	@PostMapping(value = "deleteFavByIds.action")
	public Map<String, Object> deleteFavByIds(@RequestBody String[] ids) {
		int num = 0;
		for (String favid : ids) {
			num += this.favService.deleteFav(favid);
		}
		Map<String, Object> map = new HashMap<String, Object>();
		if (num > 0) {
			map.put("success", true);
			map.put("code", num);
			map.put("message", "删除成功");
		} else {
			map.put("success", false);
			map.put("code", num);
			map.put("message", "删除失败");
		}
		return map;
	}

	// 修改用户收藏
	@PostMapping(value = "updateFav.action")
	public Map<String, Object> updateFav(@RequestBody String jsonStr) {
		JSONObject obj = JSONObject.parseObject(jsonStr); // 将JSON字符串转换成object
		Fav fav = this.favService.getFavById(obj.getString("favid")); // 获取object中favid字段
		fav.setUsersid(obj.getString("usersid")); //  为用户赋值
		fav.setGoodsid(obj.getString("goodsid")); //  为商品赋值

		Map<String, Object> map = new HashMap<String, Object>();
		int num = this.favService.updateFav(fav);
		if (num > 0) {
			map.put("success", true);
			map.put("code", num);
			map.put("message", "修改成功");
		} else {
			map.put("success", false);
			map.put("code", num);
			map.put("message", "修改失败");
		}
		return map;
	}

	// 查询全部用户收藏数据 在下拉菜单中显示
	@GetMapping(value = "getAllFav.action")
	public List<Fav> getAllFav() {
		return this.favService.getAllFav();
	}

	// 按关键字查询用户收藏数据 在下拉菜单中显示
	@GetMapping(value = "getFavMap.action")
	public Map<String, Object> getFavMap(String keywords) {
		Map<String, Object> map = new HashMap<String, Object>();
		Fav fav = new Fav();
		fav.setUsersid(keywords);
		List<Fav> list = this.favService.getFavByLike(fav);
		map.put("data", list);
		return map;
	}

	// 通过AJAX在表格中显示用户收藏数据
	@GetMapping(value = "getFavByPage.action")
	public Map<String, Object> getFavByPage(@RequestParam(defaultValue = "1") Integer page, @RequestParam(defaultValue = "10") Integer limit) {
		// 定义一个Map对象 用来返回数据
		Map<String, Object> map = new HashMap<String, Object>();
		Page<Fav> pager = com.github.pagehelper.PageHelper.startPage(page, limit);// 定义当前页和分页条数
		List<Fav> list = this.favService.getAllFav();
		// 返回的map中定义数据格式
		map.put("count", pager.getTotal());
		map.put("total", list.size());
		map.put("data", list);
		map.put("code", 0);
		map.put("msg", "");
		map.put("page", page);
		map.put("limit", limit);
		return map;
	}

	// 通过AJAX在表格中显示用户收藏数据
	@GetMapping(value = "getFav.action")
	public Map<String, Object> getFav(@RequestParam(defaultValue = "1") Integer page, @RequestParam(defaultValue = "10") Integer limit, String keywords) {
		// 定义一个Map对象 用来返回数据
		Map<String, Object> map = new HashMap<String, Object>();
		Page<Fav> pager = com.github.pagehelper.PageHelper.startPage(page, limit);// 定义当前页和分页条数
		Fav fav = new Fav();
		fav.setUsersid(keywords);
		List<Fav> list = this.favService.getFavByLike(fav);
		// 返回的map中定义数据格式
		map.put("count", pager.getTotal());
		map.put("total", list.size());
		map.put("data", list);
		map.put("code", 0);
		map.put("msg", "");
		map.put("page", page);
		map.put("limit", limit);
		return map;
	}

	// 通过AJAX在表格中显示用户收藏数据
	@GetMapping(value = "getUserFav.action")
	public Map<String, Object> getUserFav(@RequestParam(defaultValue = "1") Integer page,
			@RequestParam(defaultValue = "10") Integer limit, String id) {
		// 定义一个Map对象 用来返回数据
		Map<String, Object> map = new HashMap<String, Object>();
		Page<Fav> pager = com.github.pagehelper.PageHelper.startPage(page, limit);// 定义当前页和分页条数
		Fav fav = new Fav();
		fav.setUsersid(id);
		List<Fav> list = this.favService.getFavByLike(fav);
		// 返回的map中定义数据格式
		map.put("count", pager.getTotal());
		map.put("total", list.size());
		map.put("data", list);
		map.put("code", 0);
		map.put("msg", "");
		map.put("page", page);
		map.put("limit", limit);
		return map;
	}

	// 通过AJAX在表格中显示用户收藏数据
	@GetMapping(value = "getOwnerFav.action")
	public Map<String, Object> getOwnerFav(@RequestParam(defaultValue = "1") Integer page,
			@RequestParam(defaultValue = "10") Integer limit, String id) {
		// 定义一个Map对象 用来返回数据
		Map<String, Object> map = new HashMap<String, Object>();
		Page<Fav> pager = com.github.pagehelper.PageHelper.startPage(page, limit);// 定义当前页和分页条数
		Fav fav = new Fav();
		//fav.setAdminid(id);
		List<Fav> list = this.favService.getFavByLike(fav);
		// 返回的map中定义数据格式
		map.put("count", pager.getTotal());
		map.put("total", list.size());
		map.put("data", list);
		map.put("code", 0);
		map.put("msg", "");
		map.put("page", page);
		map.put("limit", limit);
		return map;
	}

	// 按主键查询用户收藏数据
	@GetMapping(value = "getFavById.action")
	public Fav getFavById(String id) {
		Fav fav = this.favService.getFavById(id);
		return fav;
	}

	// TODO Auto-generated method stub
}


